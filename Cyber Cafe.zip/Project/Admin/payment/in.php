<!DOCTYPE html>
<html>
  <head>
    <title>Payment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
body{
	margin: 0;
	padding: 0;
	 
	justify-content: center;
	align-items: center;
	min-height: 100vh;
	font-family: 'Jost', sans-serif;
	background: linear-gradient(to bottom,   #c55b50,  #993930,  #cd7268);
}
</style>
</head>
  <body>
    <br>
    <br>
    <div class="container fluid">
      <h1 align="center">Payment</h1>
       
      <form id="redirectForm" method="post" action="request.php">
        <div class="form-group">
          <label>Verification ID:</label><br>
          <input class="form-control" name="appId" placeholder="Enter App ID here (Ex. 123456a7890bc123defg4567)"/>
        </div>
        <div class="form-group">
          <label>Computer ID:</label><br>
          <input class="form-control" name="orderId" placeholder="Enter Order ID here (Ex. order00001)"/>
        </div>
        <div class="form-group">
          <label>Total Amount:</label><br>
          <input class="form-control" name="orderAmount" placeholder="Enter Order Amount here (Ex. 100)"/>
        </div>
        <div class="form-group">
          <label>Order Currency:</label><br>
          <input class="form-control" name="orderCurrency" value="INR" placeholder="Enter Currency here (Ex. INR)"/>
        </div>
            
        <div class="form-group">
          <label>Name:</label><br>
          <input class="form-control" name="customerName" placeholder="Enter your name here (Ex. John Doe)"/>
        </div>
        <div class="form-group">
          <label>Email:</label><br>
          <input class="form-control" name="customerEmail" placeholder="Enter your email address here (Ex. Johndoe@test.com)"/>
        </div>
        <div class="form-group">
          <label>Phone:</label><br>
          <input class="form-control" name="customerPhone" placeholder="Enter your phone number here (Ex. 9999999999)"/>
        </div>
        
        <button type="submit" class="btn btn-primary btn-block" value="Pay">Submit</button>
        <br> 
        <br>
      </form>
    </div>
    <br>    
    <br>    
    <br>    
    <br>    
  </body>
</html>